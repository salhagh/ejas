<footer class="site-footer">
      <div class="container">
        

        <div class="row">
          <div class="col-lg-9">
            <div class="row">
              <div class="col-6 col-md-3 col-lg-3 mb-3 mb-lg-0">
                <h3 class="footer-heading mb-4">For Applicants</h3>
                <ul class="list-unstyled">
                  <li><a href="/signup_page.html">Register</a></li>
                  <li><a href="index.php">Find Jobs</a></li>
                  <li><a href="#">News</a></li>
                  <li><a href="#">Search Jobs</a></li>
                  <li><a href="contact.php">Contact</a></li>
                  <li><a href="index.php">Careers</a></li>
                </ul>
              </div>
              <div class="col-3 col-md-3 col-lg-3 mb-3 mb-lg-0">
                <h3 class="footer-heading mb-4">For Organization</h3>
                <ul class="list-unstyled">
                  <li><a href="#">Employer Account</a></li>
                  <li><a href="#">Clients</a></li>
                  <li><a href="#">News</a></li>
                
                  <li><a href="#">Terms &amp; Policies</a></li>
                  <li><a href="#">Careers</a></li>
                </ul>
              </div>
              <div class="col-lg-3">
            <h3 class="footer-heading mb-4">Contact Info</h3>
            <ul class="list-unstyled">
              <li>
                <span class="d-block text-white">Address</span>
                ALbaha - 2398 10
              </li>
              <li>
                <span class="d-block text-white">Telephone</span>
                +1 232 305 3930
              </li>
              <li>
                <span class="d-block text-white">Email</span>
                info@ejas.com
              </li>
            </ul>
            
          </div>
            </div>
          </div>
          
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <p>
            Copyright &copy; <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All Rights Reserved
            </p>
          </div>
          
        </div>
      </div>
    </footer>