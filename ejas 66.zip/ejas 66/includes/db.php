<?php 


$db['db_host']="localhost";
$db['db_user']="root";
$db['db_pass']="";
$db['db_name']="ejas";

//to upper case we use the key
foreach($db as $key => $value){

define(strtoupper($key),$value);
    
}

$connection= mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

//to clean data
function escape($string){
    
    global $connection;
    
    return mysqli_real_escape_string($connection,$string);
        }


function fetch_array($result){
    
global $connection;
    
    return mysqli_fetch_array($result);
    
    
    
}  

//confirm all queries are good
function confirm($result){
    
  global $connection;
    
    
  if(!result){
      
      
      die("query failed" . mysqli_error($connection));
  }
       
    
}

//count rows or records inside the table in the database 

function row_count($result){
    
    return mysqli_num_rows($result);
  
}


function query($query){
    
global $connection;
    
$result = mysqli_query($connection,$query);
    
return $result;

}


//if($connection){
    
 //echo " WE ARE connected";
       
    
//}


?>