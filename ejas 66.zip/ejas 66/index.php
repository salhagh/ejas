
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>EJAS home-page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,700,900|Roboto+Mono:300,400,500"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/fl-bigmug-line.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->
    
    
    <?php include("includes/header.php"); ?>
    
    <div class="site-blocks-cover" style="background-image: url(images/modern.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row row-custom align-items-center">
          <div class="col-md-10">
            <h1 class="mb-2 text-black w-75"><span class="font-weight-bold">Easiest Job</span> Site On The Net</h1>
            <div class="job-search">
              <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active py-3" id="pills-job-tab" data-toggle="pill" href="#pills-job" role="tab" aria-controls="pills-job" aria-selected="true">Find A Job</a>
                </li>
                
              </ul>
              <div class="tab-content bg-white p-4 rounded" id="pills-tabContent">
                <div class="tab-pane fade show active" id="pills-job" role="tabpanel" aria-labelledby="pills-job-tab">
                  <form action="#" method="post">
                    <div class="row">
                      <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                        <input type="text" class="form-control" placeholder="eg. Web Developer">
                      </div>
                      <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                        <div class="select-wrap">
                          <span class="icon-keyboard_arrow_down arrow-down"></span>
                          <select name="" id="" class="form-control">
                            <option value="">Category</option>
                                 <?php   
                  
                  $query="SELECT * FROM job_times";
                  $select_all_job_times_query=mysqli_query($connection,$query);
                  while($row = mysqli_fetch_assoc($select_all_job_times_query) ){
                      
                    $job_time_title = $row['job_time_title']; 
                      //check it again the value of the option
                      echo "<option value={$job_time_title}>{$job_time_title}</option>";
                      
                  }
                  
                  ?>
                            
                        
                          </select>
                        </div>
                      </div>
                      <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                        <input type="text" class="form-control form-control-block search-input" id="autocomplete" placeholder="Location" onFocus="geolocate()">
                      </div>
                      <div class="col-md-6 col-lg-3 mb-3 mb-lg-0">
                        <input type="submit" class="btn btn-primary btn-block" value="Search">
                      </div>
                    </div>
                  </form>
                </div>
               
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>  
    

    <div class="site-section bg-light">
      <div class="container">
        <div class="row justify-content-start text-left mb-5">
          <div class="col-md-9" data-aos="fade">
            <h2 class="font-weight-bold text-black">Recent Jobs</h2>
          </div>
          
        </div>

       
            <?php 
            
           $query="SELECT * FROM job_posts";
            
           $select_all_job_posts_query=mysqli_query($connection,$query);

             while($row = mysqli_fetch_assoc($select_all_job_posts_query) ){
                      
                    $job_posts_title=$row['job_post_title']; 
                    $job_posts_organization = $row['job_post_org_id']; 
                    $job_post_location= $row['job_post_location']; 
                    $job_posts_time = $row['job_post_time_id']; 

                 ?>
                  <div class="row" data-aos="fade">

         <div class="col-md-12">

           <div class="job-post-item bg-white p-4 d-block d-md-flex align-items-center">

              <div class="mb-4 mb-md-0 mr-5">
               <div class="job-post-item-header d-flex align-items-center">
                 <h2 class="mr-3 text-black h4"><?php  echo $job_posts_title ?></h2>
                 <div class="badge-wrap">
                  <span class="bg-primary text-white badge py-2 px-4"><?php echo $job_posts_time ?></span>
                 </div>
               </div>
               <div class="job-post-item-body d-block d-md-flex">
                 <div class="mr-3"><span class="fl-bigmug-line-portfolio23"></span> <a href="#"><?php echo $job_posts_organization ?></a></div>
                 <div><span class="fl-bigmug-line-big104"></span> <span><?php echo $job_post_location ?></span></div>
               </div>
              </div>

              <div class="ml-auto">
                <a href="#" class="btn btn-secondary rounded-circle btn-favorite text-gray-500"><span class="icon-heart"></span></a>
                <a href="job-single.html" class="btn btn-primary py-2">View Job</a>
              </div>
           </div>

         </div>
        </div>
                 
                 
                 
            
              <?php  } ?>
       
    

        <div class="row mt-5">
          <div class="col-md-12 text-center">
            <div class="site-block-27">
              <ul>
                <li><a href="#"><i class="icon-keyboard_arrow_left h5"></i></a></li>
                <li class="active"><span>1</span></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
                <li><a href="#">5</a></li>
                <li><a href="#"><i class="icon-keyboard_arrow_right h5"></i></a></li>
              </ul>
            </div>
          </div>
        </div>


      </div>
    </div>    


    

    
 <div class="site-section">
                <div class="container">
                    <div class="row justify-content-center text-center mb-5">
                        <div class="col-md-6 aos-init aos-animate" data-aos="fade">
                            <h2 class="text-black">Why <strong>EJAS</strong> </h2>
                        </div>
                    </div>
                    <div class="row hosting">
                        <div class="col-md-6 col-lg-4 mb-5 mb-lg-4 aos-init aos-animate" data-aos="fade" data-aos-delay="100">
                            <div class="unit-3 h-100 bg-white">
                                <div class="d-flex align-items-center mb-3 unit-3-heading">
                                    <div class="unit-3-icon-wrap mr-4">
</div>
                                    <div class="unit-3-icon-wrap mr-4">
                                        <svg class="unit-3-svg" xmlns="http://www.w3.org/2000/svg" width="59px" height="68px">
                                            <path fill-rule="evenodd" stroke-width="2px" stroke-linecap="butt" stroke-linejoin="miter" fill="none" d="M29.000,66.000 L1.012,49.750 L1.012,17.250 L29.000,1.000 L56.988,17.250 L56.988,49.750 L29.000,66.000 Z"></path>
                                        </svg>
                                        <span class="unit-3-icon icon fl-bigmug-line-portfolio23"></span>
                                    </div>
                                    <h5 class="h5">Search Millions of Jobs</h5>
                                </div>
                                <div class="unit-3-body">
                                    <p>search and&nbsp;Apply for a job in the firm or company you desire , one job two jobs or many jobs you can apply as much as you want&nbsp;</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-5 mb-lg-4 aos-init aos-animate" data-aos="fade" data-aos-delay="200">
                            <div class="unit-3 h-100 bg-white">
                                <div class="d-flex align-items-center mb-3 unit-3-heading">
                                    <div class="unit-3-icon-wrap mr-4">
                                        <svg class="unit-3-svg" xmlns="http://www.w3.org/2000/svg" width="59px" height="68px">
                                            <path fill-rule="evenodd" stroke-width="2px" stroke-linecap="butt" stroke-linejoin="miter" fill="none" d="M29.000,66.000 L1.012,49.750 L1.012,17.250 L29.000,1.000 L56.988,17.250 L56.988,49.750 L29.000,66.000 Z"></path>
                                        </svg>
                                        <span class="unit-3-icon icon fl-bigmug-line-big104"></span>
                                    </div>
                                    <h2 class="h5">Location Search</h2>
                                </div>
                                <div class="unit-3-body">
                                    <p>you can search for a job based on your location or where you want to move to&nbsp;</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-5 mb-lg-4 aos-init aos-animate" data-aos="fade" data-aos-delay="300">
                            <div class="unit-3 h-100 bg-white">
                                <div class="d-flex align-items-center mb-3 unit-3-heading">
                                    <div class="unit-3-icon-wrap mr-4">
                                        <svg class="unit-3-svg" xmlns="http://www.w3.org/2000/svg" width="59px" height="68px">
                                            <path fill-rule="evenodd" stroke-width="2px" stroke-linecap="butt" stroke-linejoin="miter" fill="none" d="M29.000,66.000 L1.012,49.750 L1.012,17.250 L29.000,1.000 L56.988,17.250 L56.988,49.750 L29.000,66.000 Z"></path>
                                        </svg>
                                        <span class="unit-3-icon icon fl-bigmug-line-airplane86"></span>
                                    </div>
                                    <h2 class="h5">Top Careers</h2>
                                </div>
                                <div class="unit-3-body">
                                    <p>you can look in a list of the best most applied to and most desired jobs , and apply to the one you want&nbsp;</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-5 mb-lg-4 aos-init aos-animate" data-aos="fade" data-aos-delay="400">
                            <div class="unit-3 h-100 bg-white">
                                <div class="d-flex align-items-center mb-3 unit-3-heading">
                                    <div class="unit-3-icon-wrap mr-4">
                                        <svg class="unit-3-svg" xmlns="http://www.w3.org/2000/svg" width="59px" height="68px">
                                            <path fill-rule="evenodd" stroke-width="2px" stroke-linecap="butt" stroke-linejoin="miter" fill="none" d="M29.000,66.000 L1.012,49.750 L1.012,17.250 L29.000,1.000 L56.988,17.250 L56.988,49.750 L29.000,66.000 Z"></path>
                                        </svg>
                                        <span class="unit-3-icon icon fl-bigmug-line-user144"></span>
                                    </div>
                                    <h2 class="h5">Search Candidates</h2>
                                </div>
                                <div class="unit-3-body">
                                    <p>in the candidates list of top ten and more you can search for the one youd prefer or choose from the provided top ten.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-5 mb-lg-4 aos-init aos-animate" data-aos="fade" data-aos-delay="500">
                            <div class="unit-3 h-100 bg-white">
                                <div class="d-flex align-items-center mb-3 unit-3-heading">
                                    <div class="unit-3-icon-wrap mr-4">
                                        <svg class="unit-3-svg" xmlns="http://www.w3.org/2000/svg" width="59px" height="68px">
                                            <path fill-rule="evenodd" stroke-width="2px" stroke-linecap="butt" stroke-linejoin="miter" fill="none" d="M29.000,66.000 L1.012,49.750 L1.012,17.250 L29.000,1.000 L56.988,17.250 L56.988,49.750 L29.000,66.000 Z"></path>
                                        </svg>
                                        <span class="unit-3-icon icon fl-bigmug-line-clipboard68"></span>
                                    </div>
                                    <h2 class="h5">Easy To Manage Jobs</h2>
                                </div>
                                <div class="unit-3-body">
                                    <p>you can write the announcment and edit it whenever you want and you can set a time for the announcment to be announced or to end and our website will take care of it&nbsp;</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-5 mb-lg-4 aos-init aos-animate" data-aos="fade" data-aos-delay="600">
                            <div class="unit-3 h-100 bg-white">
                                <div class="d-flex align-items-center mb-3 unit-3-heading">
                                    <div class="unit-3-icon-wrap mr-4">
                                        <svg class="unit-3-svg" xmlns="http://www.w3.org/2000/svg" width="59px" height="68px">
                                            <path fill-rule="evenodd" stroke-width="2px" stroke-linecap="butt" stroke-linejoin="miter" fill="none" d="M29.000,66.000 L1.012,49.750 L1.012,17.250 L29.000,1.000 L56.988,17.250 L56.988,49.750 L29.000,66.000 Z"></path>
                                        </svg>
                                        <span class="unit-3-icon icon fl-bigmug-line-user143"></span>
                                    </div>
                                    <h2 class="h5">Online Reports</h2>
                                </div>
                                <div class="unit-3-body">
                                    <p>you can&nbsp; print or download pdf of the candidantes with their contact information&nbsp;</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
              <div class="site-section">
                <div class="container">
                    <div class="row justify-content-center text-center mb-5">
                        <div class="col-md-6 aos-init aos-animate" data-aos="fade">
                            <h2 class="text-black"> <strong>more about EJAS</strong> </h2>
                        </div>
                    </div>
                    <div class="row hosting text-center pb-5 h-75 mh-100">
                        <div class="unit-3-body">
                            <div class="col-md-6 col-lg-4 mb-5 mb-lg-4 aos-init aos-animate col-xl-11 col-sm-11 col-11" data-aos="fade" data-aos-delay="100">
                                <div class="unit-3-icon-wrap mr-4">
                                    <iframe width="1150px" height="600px" src="https://www.youtube.com/embed/vq5MNU6SiX0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>                                 
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    <div class="site-section block-4 bg-light">
                <div class="container">
                    <div class="row justify-content-center text-center mb-5">
                        <div class="col-md-6" data-aos="fade">
                            <h2 class="text-black">Founders</h2>
                        </div>
                    </div>
                    <div class="nonloop-block-4 owl-carousel" data-aos="fade">
                        <div class="item col-md-8 mx-auto">
                            <div class="block-38 text-center bg-white p-4">
                                <div class="block-38-img">
                                    <div class="block-38-header"> 
                                        <img src="images/1.PNG" alt="Image placeholder">
                                        <h3 class="block-38-heading">Najwa Mohammed&nbsp;</h3>
                                        <p class="block-38-subheading">website dev . ads</p>
                                    </div>
                                    <div class="block-38-body">
                                        <p>najwa is one of our wedsite devs but shes also the data base maneger , she also made ad video you can see in the home page.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item col-md-8 mx-auto">
                            <div class="block-38 text-center bg-white p-4">
                                <div class="block-38-img">
                                    <div class="block-38-header">
                                        <img src="images/2.PNG" alt="Image placeholder">
                                        <h3 class="block-38-heading">Salhah Saeed&nbsp;</h3>
                                        <p class="block-38-subheading">website dev , report</p>
                                    </div>
                                    <div class="block-38-body">
                                        <p>salhah is a web dev whos working on the applicants side , and she also is the one who created our professional website report.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item col-md-8 mx-auto">
                            <div class="block-38 text-center bg-white p-4">
                                <div class="block-38-img">
                                    <div class="block-38-header"> 
                                        <img src="images/3.PNG" alt="Image placeholder">
                                        <h3 class="block-38-heading">Rahaf Al Alyani</h3>
                                        <p class="block-38-subheading">website dev , poster creater&nbsp;</p>
                                    </div>
                                    <div class="block-38-body">
                                        <p>rahaf is one of our best web dev and shes responsible for making our amazing posters .</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
    
    <div class="py-5 bg-primary">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2 class="text-white h4 font-weihgt-normal mb-4">Subscribe Newsletter</h2>
          </div>
        </div>  
        <form action="" class="row">
          <div class="col-md-9">
            <input type="text" class="form-control border-0 mb-3 mb-md-0" placeholder="Enter Your Email">
          </div>
          <div class="col-md-3">
            <input type="submit" value="Send" class="btn btn-dark btn-block" style="height: 45px;">  
          </div>
        </form>
      </div>
    </div>
   <?php include("includes/footer.php"); ?>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>
  
  <script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&libraries=places&callback=initAutocomplete"
        async defer></script>

  <script src="js/main.js"></script>
    
  </body>
</html>